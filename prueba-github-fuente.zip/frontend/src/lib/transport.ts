import {demoRPC} from './demo';
export const rpc=demoRPC;
export function logout(){demoRPC('logout').finally(()=>window.dispatchEvent(new Event('acom-auth-expired')));}
export async function requestCode(){throw new Error('La prueba no utiliza códigos de ingreso.');}
export async function verifyCode(){throw new Error('La prueba no utiliza códigos de ingreso.');}
async function base64(file:File){const buffer=new Uint8Array(await file.arrayBuffer());let s='';for(let i=0;i<buffer.length;i+=16384)s+=String.fromCharCode(...buffer.subarray(i,i+16384));return btoa(s);}
export async function api(url:string,init?:RequestInit){
 if(url==='/api/me')return rpc('me');
 if(url.startsWith('/api/collections')&&init?.method==='POST'){const fd=init.body as FormData,file=fd.get('evidence') as File|null;if(file&&file.size>8*1024*1024)throw new Error('El comprobante debe pesar hasta 8 MB.');return rpc('create',{form:JSON.parse(String(fd.get('data'))),evidence:file?{name:file.name,type:file.type,base64:await base64(file)}:null});}
 if(url.startsWith('/api/collections/')&&init?.method==='PATCH')return rpc('update',{id:url.split('/').pop(),...JSON.parse(String(init.body))});
 if(url.startsWith('/api/collections'))return rpc('list',Object.fromEntries(new URLSearchParams(url.split('?')[1]||'')));
 if(url.startsWith('/api/audit/'))return rpc('audit',{id:url.split('/').pop()});
 if(url==='/api/team')return rpc(init?.method==='POST'?'saveMember':'team',init?.body?JSON.parse(String(init.body)):{});
 throw new Error('Operación no disponible.');
}
export async function downloadEvidence(id:string){const d=await rpc('evidence',{id});const bytes=Uint8Array.from(atob(d.base64),c=>c.charCodeAt(0));const u=URL.createObjectURL(new Blob([bytes],{type:d.type}));const a=document.createElement('a');a.href=u;a.download=d.name;a.click();setTimeout(()=>URL.revokeObjectURL(u),30000);}
