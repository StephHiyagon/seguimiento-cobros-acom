import {BRANCHES,METHODS,TERMS,cents,parseInvoiceQR,validDay,todayBO,RecordRow} from './domain';
export type Persona={id:string;email:string;name:string;role:string;active:number};
export const PERSONAS:Persona[]=[
 {id:'demo-ctc-1',email:'ctc1@example.invalid',name:'CTC de prueba 1',role:'ctc',active:1},
 {id:'demo-ctc-2',email:'ctc2@example.invalid',name:'CTC de prueba 2',role:'ctc',active:1},
 {id:'demo-comercial',email:'comercial@example.invalid',name:'Comercial de prueba',role:'comercial',active:1},
 {id:'demo-cobranzas',email:'cobranzas@example.invalid',name:'Cobranzas de prueba',role:'cobranzas',active:1},
 {id:'demo-admin',email:'admin@example.invalid',name:'Administración de prueba',role:'admin',active:1}
];
type LocalRecord=RecordRow&{fingerprint:string;bank_reference:string;audit:{at:string;action:string;actor:string;detail:string}[]};
let current:Persona|null=null;
export const isDemo=()=>true;
let database:Promise<IDBDatabase>|null=null;
function db(){if(!database)database=new Promise<IDBDatabase>((resolve,reject)=>{if(!window.indexedDB){reject(new Error('Este navegador no permite guardar la prueba. Abre el aplicativo en Chrome desde GitHub Pages.'));return;}const r=indexedDB.open('acom-cobros-demo-v1',1);r.onupgradeneeded=()=>{for(const name of ['records','proofs','team'])if(!r.result.objectStoreNames.contains(name))r.result.createObjectStore(name,{keyPath:name==='team'?'email':'id'});};r.onsuccess=()=>{r.result.onversionchange=()=>{r.result.close();database=null;};resolve(r.result);};r.onerror=()=>{database=null;reject(new Error('No se pudo abrir el almacenamiento local de prueba.'));};r.onblocked=()=>{database=null;reject(new Error('Cierra otras pestañas de la prueba y vuelve a intentarlo.'));};});return database;}
export function demoUser(){if(!current)throw new Error('Elige un perfil para probar el aplicativo.');return current;}
function role(roles:string[]){const u=demoUser();if(!roles.includes(u.role))throw new Error('Este perfil de prueba no permite esa operación.');return u;}
function visible(rows:LocalRecord[],u=demoUser()){return u.role==='ctc'?rows.filter(r=>r.collector_id===u.id):rows;}
async function readAll(){const d=await db();return new Promise<LocalRecord[]>((resolve,reject)=>{const tx=d.transaction('records','readonly'),r=tx.objectStore('records').getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(new Error('No se pudo leer la prueba.'));});}
function normalize(f:any){
 const text=(v:unknown,max=180)=>String(v??'').trim().slice(0,max);
 const r={id:text(f.id,50),client:text(f.client),client_nit:text(f.clientNit,30),number:text(f.number,20),issued_on:text(f.issuedOn,10),collected_on:text(f.collectedOn,10),branch:text(f.branch,20),amount_cents:cents(f.amount),total_cents:cents(f.total),method:text(f.method,20),terms:text(f.terms,60),receipt:text(f.receipt,100),bank_reference:text(f.bankReference,100),notes:text(f.notes,1500),cuf:text(f.cuf,100).toUpperCase(),qr:text(f.qr,600),issuer_nit:'1013899024'};
 if(!/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(r.id)||!r.client||!/^\d{1,20}$/.test(r.number)||!r.receipt)throw new Error('Completa cliente, número de factura y recibo.');
 if(!validDay(r.issued_on)||!validDay(r.collected_on)||r.issued_on>r.collected_on||r.collected_on>todayBO())throw new Error('Revisa las fechas de factura y cobro.');
 if(!(BRANCHES as readonly string[]).includes(r.branch)||!(METHODS as readonly string[]).includes(r.method)||!(TERMS as readonly string[]).includes(r.terms))throw new Error('Revisa ciudad, medio y condición del cliente.');
 if(r.method!=='Efectivo'&&!r.bank_reference)throw new Error('Ingresa la referencia bancaria.');
 if(r.cuf&&!/^[A-F0-9]{20,100}$/.test(r.cuf))throw new Error('CUF inválido.');
 if(r.qr){const q=parseInvoiceQR(r.qr);if(q.number!==r.number||q.cuf!==r.cuf)throw new Error('El número y el CUF no coinciden con el QR.');}
 return {...r,invoice_id:r.issuer_nit+':'+r.number};
}
async function proofFile(e:any,id:string){if(!e)return null;if(typeof e.base64!=='string'||e.base64.length>11200000)throw new Error('El comprobante debe pesar hasta 8 MB.');let b:Uint8Array;try{b=Uint8Array.from(atob(e.base64),c=>c.charCodeAt(0));}catch{throw new Error('El comprobante no es válido.');}if(!b.length||b.length>8*1024*1024)throw new Error('El comprobante debe pesar hasta 8 MB.');const a=[...b.slice(0,8)];const type=a[0]===255&&a[1]===216&&a[2]===255?'image/jpeg':a.join(',')==='137,80,78,71,13,10,26,10'?'image/png':a.slice(0,5).join(',')==='37,80,68,70,45'?'application/pdf':'';if(!type||type!==e.type)throw new Error('Adjunta un JPG, PNG o PDF válido.');return {id,type,name:'PRUEBA_'+id+(type==='image/jpeg'?'.jpg':type==='image/png'?'.png':'.pdf'),base64:e.base64};}
async function create(data:any){const u=role(['admin','ctc']),form=normalize(data.form||{}),fingerprint=JSON.stringify(form),proof=await proofFile(data.evidence,form.id);if(form.method==='Efectivo'&&!proof)throw new Error('Adjunta el recibo del efectivo para probar el guardado.');const d=await db();return new Promise((resolve,reject)=>{
 const tx=d.transaction(['records','proofs'],'readwrite'),store=tx.objectStore('records'),get=store.getAll();let result:any,issue='';
 tx.oncomplete=()=>resolve(result);tx.onabort=()=>reject(new Error(issue||'No se pudo guardar la prueba. Revisa el espacio disponible del navegador.'));tx.onerror=()=>{};
 get.onsuccess=()=>{try{const rows=get.result as LocalRecord[],old=rows.find(r=>r.id===form.id);if(old){if(old.collector_id!==u.id||old.fingerprint!==fingerprint)throw new Error('El ID ya corresponde a otro registro.');result={id:old.id,sync:{state:'Prueba local'}};return;}if(rows.some(r=>r.branch===form.branch&&r.receipt.toLowerCase()===form.receipt.toLowerCase()))throw new Error('Ese recibo ya está registrado en la ciudad.');const same=rows.filter(r=>r.invoice_id===form.invoice_id);if(same.some(r=>r.total_cents!==form.total_cents||r.client.toLowerCase()!==form.client.toLowerCase()||r.client_nit!==form.client_nit||r.issued_on!==form.issued_on||(r.cuf&&form.cuf&&r.cuf!==form.cuf)))throw new Error('La factura ya existe con otros datos.');const paid=same.reduce((n,r)=>n+r.amount_cents,0)+form.amount_cents;if(paid>form.total_cents)throw new Error('Los cobros acumulados superarían el total de la factura.');
 const at=new Date().toISOString();const row:LocalRecord={...form,fingerprint,evidence_key:proof?form.id:null,collector_id:u.id,collector:u.name,collector_email:u.email,recorded_at:at,status:form.method==='Efectivo'?'Por rendir':'Por verificar',received_by:null,received_at:null,close_reference:null,paid_cents:paid,audit:[{at,action:'Cobro de prueba registrado',actor:u.name,detail:form.bank_reference}]};store.add(row);if(proof)tx.objectStore('proofs').add(proof);result={id:row.id,sync:{state:'Prueba local'}};
 }catch(e){issue=(e as Error).message;tx.abort();}};
 });}
async function update(data:any){const u=role(['admin','cobranzas']),d=await db();return new Promise((resolve,reject)=>{const tx=d.transaction('records','readwrite'),store=tx.objectStore('records'),get=store.get(data.id);let issue='';tx.oncomplete=()=>resolve({id:data.id,sync:{state:'Prueba local'}});tx.onabort=()=>reject(new Error(issue||'No se pudo actualizar la prueba.'));tx.onerror=()=>{};get.onsuccess=()=>{try{const r=get.result as LocalRecord;if(!r)throw new Error('No se encontró el cobro.');if(['Recibido en oficina','Verificado en banco'].includes(r.status))throw new Error('Este cobro ya está confirmado.');const at=new Date().toISOString();if(data.action==='confirm'){if(r.collector_id===u.id)throw new Error('Selecciona otro perfil para confirmar tu propio cobro.');if(!String(data.reference||'').trim())throw new Error('Ingresa la referencia de rendición.');if(r.method==='Efectivo'&&cents(data.amount)!==r.amount_cents)throw new Error('El efectivo recibido no coincide con el cobro.');r.status=r.method==='Efectivo'?'Recibido en oficina':'Verificado en banco';r.received_at=at;r.received_by=u.name;r.close_reference=String(data.reference).slice(0,120);r.audit.push({at,action:'Confirmación de prueba',actor:u.name,detail:r.close_reference});}else if(data.action==='observe'){const reason=String(data.reason||'').trim().slice(0,1000);if(!reason)throw new Error('Escribe una observación.');r.status='Observado';r.audit.push({at,action:'Observación de prueba',actor:u.name,detail:reason});}else throw new Error('Acción no reconocida.');store.put(r);}catch(e){issue=(e as Error).message;tx.abort();}};});}
export async function demoRPC(action:string,data:any={}):Promise<any>{
 if(action==='demoLogin'){const u=PERSONAS.find(p=>p.id===data.persona);if(!u)throw new Error('Selecciona un perfil de prueba.');current=u;return u;}
 if(action==='logout'){current=null;return {ok:true};}
 const u=demoUser();
 if(action==='me')return u;
 if(action==='create')return create(data);
 if(action==='update')return update(data);
 if(action==='list'||action==='export'){
  let rows=visible(await readAll(),u).filter(r=>(!data.branch||r.branch===data.branch)&&(!data.status||r.status===data.status)&&(!data.from||r.collected_on>=data.from)&&(!data.to||r.collected_on<=data.to));
  if(data.q){const q=String(data.q).toLowerCase();rows=rows.filter(r=>[r.client,r.number,r.receipt,r.collector].join(' ').toLowerCase().includes(q));}
  rows.sort((a,b)=>b.recorded_at.localeCompare(a.recorded_at));if(action==='export')return rows;
  const stats={count:rows.length,total:0,pending_cash:0,pending_bank:0};rows.forEach(r=>{stats.total+=r.amount_cents;if(!['Recibido en oficina','Verificado en banco'].includes(r.status))stats[r.method==='Efectivo'?'pending_cash':'pending_bank']+=r.amount_cents;});const page=Math.max(1,Number(data.page)||1);return {rows:rows.slice((page-1)*30,page*30),stats,sync:{state:'Prueba local'}};
 }
 if(action==='audit'||action==='evidence'){const r=visible(await readAll(),u).find(r=>r.id===data.id);if(!r)throw new Error('No se encontró el cobro para este perfil.');if(action==='audit')return r.audit;const d=await db();return new Promise((resolve,reject)=>{const get=d.transaction('proofs','readonly').objectStore('proofs').get(r.id);get.onsuccess=()=>get.result?resolve(get.result):reject(new Error('El cobro no tiene comprobante.'));get.onerror=()=>reject(new Error('No se pudo leer el comprobante.'));});}
 if(action==='team'){role(['admin']);return PERSONAS;}
 if(action==='saveMember')throw new Error('La prueba utiliza perfiles ficticios fijos. Los correos corporativos se configurarán al conectar el servicio.');
 if(action==='reset'){const d=await db();await new Promise<void>((resolve,reject)=>{const tx=d.transaction(['records','proofs'],'readwrite');tx.objectStore('records').clear();tx.objectStore('proofs').clear();tx.oncomplete=()=>resolve();tx.onabort=()=>reject(new Error('No se pudieron borrar los datos de prueba.'));});return {ok:true};}
 throw new Error('Esta función estará disponible al conectar el servicio.');
}
