declare global {interface Window {__ACOM_WASM_GZIP__?:string}}
let decoder:Promise<typeof import('zxing-wasm/reader')>|null=null;
export async function decodeQR(input:Blob|ImageData){
 if(!decoder)decoder=import('zxing-wasm/reader').then(async m=>{
  if(!window.__ACOM_WASM_GZIP__||!window.DecompressionStream)throw new Error('Este navegador no es compatible con el lector QR. Utiliza el ingreso manual.');
  const bytes=Uint8Array.from(atob(window.__ACOM_WASM_GZIP__),c=>c.charCodeAt(0));
  const wasm=new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());
  m.prepareZXingModule({overrides:{wasmBinary:wasm}});return m;
 }).catch(e=>{decoder=null;throw e;});
 const m=await decoder,results=await m.readBarcodes(input,{formats:['QRCode'],tryHarder:true,maxNumberOfSymbols:1});return results[0]?.text||'';
}
