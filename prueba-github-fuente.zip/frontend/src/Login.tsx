import {useState,FormEvent} from 'react';
import {FlaskConical} from 'lucide-react';
import {PERSONAS,demoRPC} from './lib/demo';
export default function Login({onLogin}:{message:string;onLogin:(u:any)=>void}){
 const[persona,P]=useState(PERSONAS[0].id),[error,E]=useState('');
 async function submit(e:FormEvent){e.preventDefault();try{onLogin(await demoRPC('demoLogin',{persona}));}catch(e){E((e as Error).message);}}
 return <section className="auth-card"><FlaskConical size={35}/><h1>Probar el aplicativo</h1><p>Elige un perfil ficticio para recorrer el registro y la rendición de un cobro. No necesitas iniciar sesión.</p><form onSubmit={submit}><label>Perfil de prueba<select value={persona} onChange={e=>P(e.target.value)}>{PERSONAS.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label>{error&&<div className="alert error">{error}</div>}<button className="primary">Entrar a la prueba</button><p>Usa datos ficticios. Los registros se guardan solo en este navegador. El selector de perfiles simula los roles; no verifica identidad.</p></form></section>;
}
